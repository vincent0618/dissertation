clc;
clear;

data =  xlsread('16 year ret.xlsx');
returns = data(:,2:31);
mvoweight =  xlsread('MVO Max Sharpe Ratio Portfolio.xlsx');
cvarweight = xlsread('CVaR Max Sharpe Ratio Portfolio.xlsx');

for i=1:16
mvoret(i,:) = returns(i,:)*mvoweight(:,i);
end
 
for i=1:16
cvarret(i,:) = returns(i,:)*cvarweight(:,i);
end
 
