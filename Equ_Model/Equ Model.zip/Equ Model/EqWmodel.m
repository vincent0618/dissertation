clc;
clear;

data = csvread('16 yearly return.csv',1,1);

for i =1:16
    year = data((12*i-11):(12*i),:);
    yret = prod(year);
    tret(i,:) = yret;
end
        
ret = sum(tret,2)/30;