clc;
clear;

data = csvread('return data1.csv',1,1);
weight = xlsread('CVaR Max Sharpe Ratio Portfolio');

fmt = repmat( '%g ', 1, 240 );
fmt = [ fmt(1:end-1) '\n' ];
for i=1:16
    
    ret=data((12*i-11):(12*i+48),:);
    P = ret*weight(:,i);
    
    fid = fopen( ['return_benchmark' num2str(i) '.txt'], 'wt' );
    if fid
        fprintf( fid, fmt, P' );
        fclose(fid);
    else
        fprintf( 'Error: Pj%d.txt\n' ,i);
    end
end