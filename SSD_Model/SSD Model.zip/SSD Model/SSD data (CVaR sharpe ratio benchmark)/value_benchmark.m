clc;
clear;

for i =1:16
    filename = ['return_benchmark' num2str(i) '.csv'];
    returnbenchmark =  csvread(filename);
    fmt = repmat( '%g ', 1, 60 );
    fmt = [ fmt(1:end-1) '\n' ];
    for j=1:60     
        v = returnbenchmark(1,j)- returnbenchmark;
        v(v<0) = 0;
        c(j,:) = v;
        vben(:,j) = sum(v,2)/60;
      
    fid = fopen( ['value_benchmark' num2str(i) '.txt'], 'wt' );
    if fid
        fprintf( fid, fmt, vben' );
        fclose(fid);
    else
        fprintf( 'Error: Pj%d.txt\n' ,i);
    end
    end
end
        