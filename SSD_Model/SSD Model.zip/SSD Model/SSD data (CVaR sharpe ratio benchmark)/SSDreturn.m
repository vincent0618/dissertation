clc;
clear;

data = csvread('return data.csv',1,1);

for i =1:16
    fiveyear = data((12*i-11):(12*i+48),:);
    fiveyret = exp(sum(log(fiveyear))/60);
    georet(i,:) = fiveyret;
end
        