clc;
clear;

returns =  xlsread('16 year ret.xlsx');
for i =1:16
    weight =  xlsread('SSD CVaR SR Weight.xlsx');
    SixteenRet(i,:) = returns(i,2:31)*weight(:,i);
end
        
