clc;
clear;

data = csvread('return data1.csv',1,1);

fmt = repmat( '%g ', 1, 240 );
fmt = [ fmt(1:end-1) '\n' ];
for i=1:16
    
    ret=data((12*i-11):(12*i+48),:);
    P = sum(ret,2)/30;
    
    fid = fopen( ['return_benchmark' num2str(i) '.csv'], 'wt' );
    if fid
        fprintf( fid, fmt, P' );
        fclose(fid);
    else
        fprintf( 'Error: Pj%d.txt\n' ,i);
    end
end