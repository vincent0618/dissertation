clc;
clear;

data = csvread('return_benchmark1.csv');

 for j=1:60     
        v = data(1,j)- data;
        v(v<0) = 0;
        c(j,:) = v;
        vben(:,j) = sum(v,2)/60;
 end