clear;
clc; 

% read the data file 
[Returns,textdate] =  xlsread('09-13.xlsx');

assetTickers = textdate(1,2:31);

%Setup portfolio
pmc = PortfolioCVaR;
pmc = pmc.setAssetList(assetTickers);
pmc = pmc.setScenarios(Returns);
pmc = pmc.setDefaultConstraints;
pmc = pmc.setProbabilityLevel(0.95);

%Plot the CVaR efficient frontier
pmcwgts = pmc.estimateFrontier(10);

[pmcRisk, pmcReturns] = pmc.plotFrontier(pmcwgts);

figure;
pmc.plotFrontier(10);

saveas(gcf,['C:\Users\s1416138\Downloads\09-13\','EFCVaR','.jpg']);

% MVO model

pmv = Portfolio;
pmv = pmv.setAssetList(assetTickers);
pmv = pmv.estimateAssetMoments(Returns);
pmv = pmv.setDefaultConstraints;

pmvwgts = pmv.estimateFrontier(10);

[pmvRisk, pmvReturns] = pmv.plotFrontier(pmvwgts);

pmcRiskStd = pmc.estimatePortStd(pmcwgts);

% Estimate Max Sharpe Ratio
pwgt = estimateMaxSharpeRatio(pmv);
[risk, ret] = estimatePortMoments(pmv, pwgt);
hold on
plot(risk,ret,'*r');

% Max Sharpe Ratio in CVaR model
pwgt2 = estimateFrontierByReturn(pmc, ret);

% portfolio weight plot
figure;
pmv.plotFrontier(10);
saveas(gcf,['C:\Users\s1416138\Downloads\09-13\','EFMVO','.jpg']);

hold on

plot(pmcRiskStd,pmcReturns,'-r','LineWidth',2);
legend('Mean-Variance Efficient Frontier',...
       'CVaR Efficient Frontier',...
       'Location','SouthEast')
saveas(gcf,['C:\Users\s1416138\Downloads\09-13\','EFTwo','.jpg']);

figure; 

%subplot(1,2,1);
area(pmcwgts');
title('CVaR Portfolio Weights');
set(get(gcf,'Children'),'YLim',[0 1]);
colormap jet;
%legend(pmv.AssetList);
saveas(gcf,['C:\Users\s1416138\Downloads\09-13\','WtCVaR','.jpg']);

figure; 
%subplot(1,2,2);
area(pmvwgts');
title('Mean-Variance Portfolio Weights');
set(get(gcf,'Children'),'YLim',[0 1]);
colormap jet;
%legend(pmv.AssetList);
saveas(gcf,['C:\Users\s1416138\Downloads\09-13\','WtMVP','.jpg']);
