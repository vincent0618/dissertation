clc;
clear;

returns =  xlsread('16 year ret.xlsx');
for i =1:16
    filename = ['CVaR' num2str(i) '.xlsx'];
    weight =  xlsread(filename);
    SixteenRet(i,:) = returns(i,2:31)*weight;
end
        
